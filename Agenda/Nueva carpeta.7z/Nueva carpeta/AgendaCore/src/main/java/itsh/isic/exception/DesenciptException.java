package itsh.isic.exception;

public class DesenciptException extends Exception {
	private static final long serialVersionUID = 7860552243422600993L;

	public DesenciptException(final String message) {
		super(message);
	}

	public DesenciptException(final Throwable throwable) {
		super(throwable);
	}

	public DesenciptException(final String message, final Throwable throwable) {
		super(message, throwable);
	}

}
