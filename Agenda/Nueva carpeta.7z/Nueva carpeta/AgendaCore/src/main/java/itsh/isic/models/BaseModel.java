package itsh.isic.models;

public class BaseModel {

	private String CodRetorno;
	private String Mensaje;

	public String getCodRetorno() {
		return CodRetorno;
	}

	public void setCodRetorno(String codRetorno) {
		CodRetorno = codRetorno;
	}

	public String getMensaje() {
		return Mensaje;
	}

	public void setMensaje(String mensaje) {
		Mensaje = mensaje;
	}

}
