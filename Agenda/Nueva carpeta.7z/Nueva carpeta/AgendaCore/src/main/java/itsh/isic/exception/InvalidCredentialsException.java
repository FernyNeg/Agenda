package itsh.isic.exception;

public class InvalidCredentialsException extends Exception {
	private static final long serialVersionUID = -4895314420972768132L;

	public InvalidCredentialsException(final String message) {
		super(message);
	}

}
