package itsh.isic.enums;

public enum NumerosEnum {

	UNO(1), DOS(2),;

	private Integer numero;

	NumerosEnum(final Integer num) {
		this.numero = num;
	}

	public Integer getNumero() {
		return numero;
	}

}
