package itsh.isic.enums;

public enum StatusContactoEnum {
	/*
	 * Enumerador con los stados disponibles para los contactos
	 */
	ACTIVO, INACTIVO, AUSENTE, BLOQUEADO;
}