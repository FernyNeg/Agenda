package itsh.isic.constantes;

public class Constantes {
	/*
	 * contantes que se utilizaran a lo largo del proyecto
	 * */
	public static final String COMMA = ", ";
	public static final String BLANK = "";
	
	public static final String COD_STATUS_ERROR = "ERROR";
	public static final String HEADER_MESSAGE = "MESSAGE";
	
	public static final String HEADER_CONTET = "Content-Type";
	public static final String HEADER_RESQUESTWITH_KEY = "x-requested-with";
	public static final String HEADER_TOKEN_AUT = "X-Auth-Token";
	public static final String HEADER_AUTHORIZACION_KEY = "authorization";
	public static final String HEADER_AUTH_KEY = "Auth";
	public static final String HEADER_STATUS = "COD_STATUS";
}
