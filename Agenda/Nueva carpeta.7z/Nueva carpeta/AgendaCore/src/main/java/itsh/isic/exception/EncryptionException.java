package itsh.isic.exception;

public class EncryptionException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public EncryptionException(Throwable t) {
		super(t);
	}
}
