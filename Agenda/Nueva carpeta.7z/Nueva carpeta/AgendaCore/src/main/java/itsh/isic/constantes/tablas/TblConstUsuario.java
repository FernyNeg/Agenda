package itsh.isic.constantes.tablas;

public class TblConstUsuario {

	public static final String COL_IDUSER = "idUser";
	public static final String COL_APODO = "apodo";
	public static final String COL_CORREO = "correo";
	public static final String COL_CONTRASENIA = "contrasenia";
	public static final String COL_CANTINTENTOS = "cantIntentos";
	
}
