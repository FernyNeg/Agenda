package itsh.isic.models;

import itsh.isic.enums.StatusContactoEnum;

public class UsuarioModel extends BaseModel {

	private Integer id;
	private String apodo;
	private String correo;
	private String contrasenia;
	private String nombre;
	private String aPaterno;
	private String aMaterno;
	private String nomCompleto;
	private Integer numIntentos;
	private StatusContactoEnum estatus;

	public Integer getNumIntentos() {
		return numIntentos;
	}

	public void setNumIntentos(Integer numIntentos) {
		this.numIntentos = numIntentos;
	}

	public String getNomCompleto() {
		this.nomCompleto = this.getNombre() + this.getaPaterno() + this.getaMaterno();
		return nomCompleto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getApodo() {
		return apodo;
	}

	public void setApodo(String apodo) {
		this.apodo = apodo;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getContrasenia() {
		return contrasenia;
	}

	public void setContrasenia(String contrasenia) {
		this.contrasenia = contrasenia;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getaPaterno() {
		return aPaterno;
	}

	public void setaPaterno(String aPaterno) {
		this.aPaterno = aPaterno;
	}

	public String getaMaterno() {
		return aMaterno;
	}

	public void setaMaterno(String aMaterno) {
		this.aMaterno = aMaterno;
	}

	public StatusContactoEnum getEstatus() {
		return estatus;
	}

	public void setEstatus(StatusContactoEnum estatus) {
		this.estatus = estatus;
	}

}
