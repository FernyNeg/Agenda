package itsh.isic.dao.login;

import itsh.isic.exception.DatabaseException;
import itsh.isic.exception.EmptyResultException;
import itsh.isic.models.UsuarioModel;

public interface LoginDao {

	boolean estaBloqueadoUsuario(String usuario, String correo) throws DatabaseException;

	UsuarioModel getUsuarioParaSesionCorreoOrUser(final String username, final String correo)
			throws EmptyResultException, DatabaseException;

	Integer getContraseniaPorApodo(final String username, final String correo, final String password)
			throws DatabaseException;

	void registraIntento(final Integer idUser, final Integer retryNumber) throws DatabaseException;

}
