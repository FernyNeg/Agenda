package itsh.isic.controller.security;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import itsh.isic.constantes.Constantes;
import itsh.isic.constantes.UrlConstantes;
import itsh.isic.exception.BlockedUserException;
import itsh.isic.exception.BusinessException;
import itsh.isic.models.UsuarioModel;
import itsh.isic.service.security.LoginService;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class LoginController {
	
	private static final Logger log = Logger.getLogger(LoginController.class);

	@Autowired
	private LoginService userBusiness;

	@RequestMapping(value = UrlConstantes.LOGIN, method = RequestMethod.POST)
	@ResponseBody
	public UsuarioModel login(@RequestBody UsuarioModel user, final HttpServletResponse response)
			throws BusinessException {

//        this.binnacleBusiness.save(LoggingUtils.createBinnacleForLogging("Intento de Logueo del Usuario: " +   user.getUsername(), this.session, LogCategoryEnum.TRY));
		try {
			user = this.userBusiness.validateUserCredentials(user.getApodo(), user.getContrasenia());
			this.setUserProfileAndSession(user);
//			this.binnacleBusiness
//					.save(LoggingUtils.createBinnacleForLogging("Logueo del Usuario", this.session, LogCategoryEnum.LOGIN));
			return user;
		} catch (BlockedUserException businessException) {
//			this.binnacleBusiness.save(LoggingUtils.createBinnacleForLogging(
//					"Usuario: " + user.getUsername() + ". Bloqueado.", this.session, LogCategoryEnum.BLOCK));
			response.setHeader(Constantes.HEADER_STATUS, Constantes.COD_STATUS_ERROR);
			response.setHeader(Constantes.HEADER_MESSAGE, businessException.getMessage());
		} catch (BusinessException businessException) {
			log.error(businessException.getMessage(), businessException);
			response.setHeader(Constantes.HEADER_STATUS, Constantes.COD_STATUS_ERROR);
			response.setHeader(Constantes.HEADER_MESSAGE, businessException.getMessage());
		}
		return new UsuarioModel();
	}
	
  private void setUserProfileAndSession(final UsuarioModel user) throws BusinessException {
    user.setContrasenia(Constantes.BLANK);
    user.setApodo(Constantes.BLANK);
//    user.setProfileList(this.userBusiness.findProfilesByidUser(user.getId()));
//    this.session.setIdUsuarioSession(user.getId());
//    this.session.setUsuario(user);
}

}
