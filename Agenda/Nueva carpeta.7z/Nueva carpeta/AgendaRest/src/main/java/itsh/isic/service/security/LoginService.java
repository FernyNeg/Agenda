package itsh.isic.service.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.yaml.snakeyaml.external.biz.base64Coder.Base64Coder;
import org.slf4j.Logger;

import itsh.Desenciptador;
import itsh.isic.dao.login.LoginDao;
import itsh.isic.enums.MsjEnum;
import itsh.isic.enums.NumerosEnum;
import itsh.isic.enums.StatusContactoEnum;
import itsh.isic.exception.BlockedUserException;
import itsh.isic.exception.BusinessException;
import itsh.isic.exception.DatabaseException;
import itsh.isic.exception.DesenciptException;
import itsh.isic.exception.EmptyResultException;
import itsh.isic.exception.InvalidCredentialsException;
import itsh.isic.models.UsuarioModel;
import itsh.isic.utilidades.SeguridadService;

@Service
public class LoginService {

	private static final Logger log = Logger.getLogger(LoginService.class);
	private static final String clase = "LoginService: ";
	private static final Integer CERO_INTENTES_EN_LOGIN = 0;

	@Autowired
	@Lazy
	private LoginDao userable;

	public UsuarioModel validateUserCredentials(final String username, final String password)
			throws BusinessException, BlockedUserException {
		UsuarioModel user = new UsuarioModel();
		try {
			final String userNameEncripted = this.encryptUsername(username);
			this.validateIsNoBlockedUser(userNameEncripted, user.getCorreo());
			user = this.getUsuarioParaSesion(userNameEncripted, user.getCorreo());
			this.validateCredentials(userNameEncripted, user.getCorreo(),
					this.signOn(password, user.getContrasenia(), user.getEstatus()));
			this.userable.registraIntento(user.getId(), CERO_INTENTES_EN_LOGIN);
			log.info("Inicio de sesión del usuario: " + user.getNomCompleto() + ", con Id: " + user.getId());
			return user;
		} catch (DatabaseException | DesenciptException databaseException) {
			log.error(MsjEnum.ERROR_VALIDANDO_CREDENTIALES.getDescripcion() + ": " + username, databaseException);
			throw new BusinessException(MsjEnum.ERROR_VALIDANDO_CREDENTIALES.getDescripcion(),
					databaseException.getMessage());
		} catch (InvalidCredentialsException | EmptyResultException invalidCredentialsException) {
			this.registerInvalidAttempt(user, invalidCredentialsException);
			throw new BusinessException(MsjEnum.INVALID_CREDENTIALS_MESSAGE.getDescripcion(),
					invalidCredentialsException.getMessage());
		}
	}

	private boolean isInvalidCredentials(final String apodo, final String correo, final String contrasenia)
			throws DatabaseException {
		return this.userable.getContraseniaPorApodo(apodo, correo, contrasenia) != NumerosEnum.UNO.getNumero();
	}

	private void validateCredentials(final String username, final String correo, final String password)
			throws DatabaseException, InvalidCredentialsException {
		if (this.isInvalidCredentials(username, correo, password))
			throw new InvalidCredentialsException(MsjEnum.INVALID_CREDENTIALS_MESSAGE.getDescripcion());
	}

	private String signOn(final String pass, final String salt, final StatusContactoEnum status)
			throws BusinessException {
		log.info("Login:Validando Datos Password");
		if (status == StatusContactoEnum.ACTIVO)
			return SeguridadService.encrypt(pass, Base64Coder.encodeString(salt));
		throw new BusinessException(MsjEnum.INVALID_CREDENTIALS_MESSAGE.getDescripcion(), "");
	}

	private void registerInvalidAttempt(final UsuarioModel user, final Exception invalidCredentialsException)
			throws BusinessException, BlockedUserException {
		log.error(invalidCredentialsException.getMessage());
		this.registerAttemptWhenInvalidCredentials(invalidCredentialsException, user);
	}

	private void registerAttemptWhenInvalidCredentials(final Exception exception, final UsuarioModel user)
			throws BusinessException, BlockedUserException {
		if (exception instanceof InvalidCredentialsException)
			this.registerFailedAccessAttempt(user);
	}

	private void registerFailedAccessAttempt(final UsuarioModel user) throws BusinessException, BlockedUserException {
		try {
			user.setNumIntentos(user.getNumIntentos() + 1);
			log.info("Registrando acceso fallido para el usuario con id: " + user.getId() + ". Intento número: "
					+ user.getNumIntentos());
			final Integer maxIntentos = Integer.parseInt(this.configurable.findByName("LOGIN_RETRIES"));
			this.userable.registraIntento(user.getId(), user.getNumIntentos());
			if (user.getNumIntentos() >= maxIntentos) {
				this.userable.changeUserStatus(user.getId(), StatusContactoEnum.BLOQUEADO);
				throw new BlockedUserException(MsjEnum.MESSAGE_BLOCLED_USER_ERROR.getDescripcion());
			}
		} catch (DatabaseException databaseException) {
			throw new BusinessException("Hubo un problema al registrar el reintento de login",
					databaseException.getMessage());
		}
	}

	private UsuarioModel getUsuarioParaSesion(final String username, final String correo)
			throws DatabaseException, EmptyResultException, DesenciptException {
		return this.userable.getUsuarioParaSesionCorreoOrUser(username, correo);
	}

	private void validateIsNoBlockedUser(final String userNameEncripted, final String correo)
			throws BlockedUserException, DatabaseException {
		if (this.userable.estaBloqueadoUsuario(userNameEncripted, correo))
			throw new BlockedUserException(MsjEnum.MESSAGE_BLOCLED_USER_ERROR.getDescripcion());
	}

	private String encryptUsername(final String username) throws DesenciptException {
		final Desenciptador encryptor = new Desenciptador();
		return encryptor.encrypt(username);
	}

}
